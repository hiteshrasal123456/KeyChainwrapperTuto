//
//  ViewController.swift
//  KeyChainTuto
//
//  Created by Tejora on 07/05/20.
//  Copyright © 2020 Tejora. All rights reserved.
//  GITHUB LINK - https://github.com/jrendel/SwiftKeychainWrapper

import UIKit
import SwiftKeychainWrapper
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        fetchNameFrmKeyChain()
        
    }
    // MARK : SAVE VALUE TO KEYCHAIN
    func saveNameInKeyChain() {
       KeychainWrapper.standard.set("Hitesh", forKey: "name")
    }
    // MARK : FETCH VALUE FROM KEYCHAIN
    func fetchNameFrmKeyChain() {
        let name =  KeychainWrapper.standard.string(forKey: "name")
        print("fetched value from keychain is \(String(describing: name))")
    }
}


